package br.ufg.persistencia.agendacao_vacinacao.model;

public class Agenda {
}
