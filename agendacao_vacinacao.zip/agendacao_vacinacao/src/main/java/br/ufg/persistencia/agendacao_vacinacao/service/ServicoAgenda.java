package br.ufg.persistencia.agendacao_vacinacao.service;

public class ServicoAgenda {
}
