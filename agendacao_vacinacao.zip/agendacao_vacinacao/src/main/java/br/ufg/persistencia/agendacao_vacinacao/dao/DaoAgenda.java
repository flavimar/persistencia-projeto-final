package br.ufg.persistencia.agendacao_vacinacao.dao;

public class DaoAgenda {
}
