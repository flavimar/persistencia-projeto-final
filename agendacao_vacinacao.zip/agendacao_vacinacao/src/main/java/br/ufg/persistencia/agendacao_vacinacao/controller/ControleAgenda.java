package br.ufg.persistencia.agendacao_vacinacao.controller;

public class ControleAgenda {
}
